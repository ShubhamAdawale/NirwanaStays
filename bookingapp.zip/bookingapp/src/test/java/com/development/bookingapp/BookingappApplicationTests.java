package com.development.bookingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
