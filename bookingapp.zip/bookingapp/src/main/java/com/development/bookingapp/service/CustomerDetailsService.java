package com.development.bookingapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.development.bookingapp.repository.CustomerDetailsRepository;
import com.development.bookingapp.model.CustomerDetailsModel;

@Service
public class CustomerDetailsService {
	@Autowired
	CustomerDetailsRepository repo;
	
	public CustomerDetailsModel saveData(CustomerDetailsModel data) {
		return repo.save(data);
	}
}
