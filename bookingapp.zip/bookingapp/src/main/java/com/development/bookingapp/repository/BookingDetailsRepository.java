package com.development.bookingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.development.bookingapp.model.BookingDetailsModel;

import jakarta.transaction.Transactional;

@Transactional
@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetailsModel,Integer> {

}
