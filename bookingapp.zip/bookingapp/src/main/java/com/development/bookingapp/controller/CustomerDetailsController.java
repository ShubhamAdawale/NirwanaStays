package com.development.bookingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.development.bookingapp.model.CustomerDetailsModel;
import com.development.bookingapp.repository.CampRepository;
import com.development.bookingapp.repository.CustomerDetailsRepository;
import com.development.bookingapp.service.CampService;
import com.development.bookingapp.service.CustomerDetailsService;

@RestController
@RequestMapping("/customer")
@CrossOrigin(value = "${base.url}")
public class CustomerDetailsController {
	@Autowired
	CustomerDetailsService customerservice;
	@Autowired
	CustomerDetailsRepository repo;
	@PostMapping("/customerdata")
	public CustomerDetailsModel saveData(@RequestBody CustomerDetailsModel customerData) {
		System.out.println(customerData);
		return customerservice.saveData(customerData);
	}
}
