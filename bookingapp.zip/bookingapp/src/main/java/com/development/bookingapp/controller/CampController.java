package com.development.bookingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.development.bookingapp.model.CampData;
import com.development.bookingapp.repository.CampRepository;
import com.development.bookingapp.service.CampService;

@RestController
@RequestMapping("/camp")
@CrossOrigin(value = "${base.url}")
public class CampController {
	@Autowired
	CampService campservice;
	@Autowired
	CampRepository repo;
	@PostMapping("/getcount")
	private String checkAvailability(String checkin,String checkout,int adults,int children) {
		int capacity=20;
		int count = campservice.getBooking(checkin,checkout,adults,children);
		System.out.println(count);
		if(capacity>=count) {
			return "available";
		}
		else {
			return "not available";
		} 
	}
}
