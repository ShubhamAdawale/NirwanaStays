package com.development.bookingapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.development.bookingapp.model.BookingDetailsModel;
import com.development.bookingapp.model.CustomerDetailsModel;
import com.development.bookingapp.repository.BookingDetailsRepository;
@Service
public class BookingDetailsService {
	@Autowired
	BookingDetailsRepository repo;
	public BookingDetailsModel saveData(BookingDetailsModel data) {
		return repo.save(data);
	}
}
